﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica3UI.Forms
{
    public partial class Practica3 : Form
    {
        public Practica3()
        {
            InitializeComponent();
        }
        private bool img = true;
        private void button1_Click(object sender, EventArgs e)
        {
            //utilizar la clase openfiledialog para visualizar la ventana.
            OpenFileDialog abrir = new OpenFileDialog();

            //filtro para abrir imagenes JPG...
            abrir.Filter = "JPEG(* JPG)|*JPG|BMP(*.BMP) |*.BMP";

            //validar ventana y visualizarla.
            //ShowDialog abre una ventana, el if valida nuestra respuesta.
            if (abrir.ShowDialog() == DialogResult.OK)
            {
                //validaciones sobre ventanas img.
                //obteniendo la ruta de la imagen y el nombre del archivo.
                pictureBox1.Image = Image.FromFile(abrir.FileName);
            }
            else
            {

            }
        }
        private bool isimg = true;
        private void button2_Click(object sender, EventArgs e)
        {
            //uso de la estructura de condición.
            if (isimg)
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\Javie\\OneDrive\\Escritorio\\descargar.jpg");
                isimg = false;
            }
            else
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\Javie\\OneDrive\\Escritorio\\Full Stack Developer.jpg");
                isimg = true;
            }
        }
        //timer para asignarle un tiempo de cambio a las imagenes sin usar un button.
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isimg)
            {
                pictureBox3.Image = Image.FromFile("C:\\Users\\Javie\\OneDrive\\Escritorio\\descargar.jpg");
                isimg = false;
            }
            else
            {
                pictureBox3.Image = Image.FromFile("C:\\Users\\Javie\\OneDrive\\Escritorio\\Full Stack Developer.jpg");
                isimg = true;
            }
        }
    }
}